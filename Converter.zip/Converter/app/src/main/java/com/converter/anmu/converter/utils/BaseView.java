package com.converter.anmu.converter.utils;

public interface BaseView<T> {

}
