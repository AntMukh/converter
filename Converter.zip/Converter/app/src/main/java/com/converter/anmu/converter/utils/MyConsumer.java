package com.converter.anmu.converter.utils;

public interface MyConsumer<T> {
    public void accept(T object);
}
