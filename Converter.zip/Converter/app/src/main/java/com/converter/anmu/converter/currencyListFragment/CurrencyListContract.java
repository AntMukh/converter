package com.converter.anmu.converter.currencyListFragment;

import android.content.Context;

import com.converter.anmu.converter.utils.BasePresenter;
import com.converter.anmu.converter.utils.BaseView;
import com.converter.anmu.converter.Currency;

public interface CurrencyListContract {

        interface View extends BaseView<Presenter> {
            Context getContext();
        }

        interface Presenter extends BasePresenter<View> {
            public void onItemClick(Currency clickedCurrency);
        }
}
