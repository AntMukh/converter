package com.converter.anmu.converter.currencyListFragment;

import com.converter.anmu.converter.ConverterApplication;
import com.converter.anmu.converter.Currency;
import com.converter.anmu.converter.MainActivity.MainConverterActivityPresenter;

public class CurrencyListPresenter implements CurrencyListContract.Presenter{

    private CurrencyListContract.View view;
    MainConverterActivityPresenter mainConverterActivityPresenter;

    public void bindView(CurrencyListContract.View view){
        this.view = view;
        mainConverterActivityPresenter = ((ConverterApplication)view.getContext().getApplicationContext()).provideMainActivityPresenter();
    }

    public void unBindView(){
        this.view = null;
    }

    public void onItemClick(Currency clickedCurrency){
        mainConverterActivityPresenter.detachBottomFragment();
        mainConverterActivityPresenter.passCode(clickedCurrency.getCode());
    }
}
