package com.converter.anmu.converter;

import com.converter.anmu.converter.utils.Converter;

import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
public class ExampleUnitTest {
    @Test
    public void convetrt_test() throws Exception {
        double result = Converter.convert(245, 1.89);
        assertEquals(result, 245*1.89, 0.001);
    }


    @Test
    public void crossRateTest() throws Exception{
        double result = Converter.calculateCrossRate( 0.85, 8.67);
        assertEquals(result, 10.20, 0.1);
    }
}